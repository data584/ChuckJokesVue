# ChuckJokesVue

Aplicación construida con **Vue 3 + Bootstrap 5 + PHP** (servida por Apache de XAMPP / WAMP / MAMP / LAMP / Laragon) que muestra una galería de bromas de Chuck Norris en tarjetas estilo Bootstrap.

## Tecnologías

- HTML5 / CSS3
- **Vue 3** (CDN)
- **Bootstrap 5** (CDN)
- **PHP** (servido por Apache)

## Estructura del proyecto

```
ChuckJokesVue/
├── index.php           → Vista principal (renderizada por PHP/Apache)
├── api/
│   └── jokes.php       → Endpoint que devuelve los datos en JSON
├── css/
│   └── styles.css      → Estilos personalizados (complementan Bootstrap)
├── js/
│   └── app.js          → Instancia Vue + componente <chuck-card>
├── .htaccess           → Configuración Apache
├── .gitignore
└── README.md
```

## Características cumplidas

1. **Componente `<chuck-card>`** basado en una card de Bootstrap (imagen superior + texto descriptivo).
2. **Props** `icon_url` y `value` para enviar los datos entre componentes.
3. **Distribución de tarjetas**: 3 cards en la primera fila y 2 en la segunda fila usando el sistema de grid de Bootstrap (`col-lg-4`).
4. Backend en PHP servido por Apache (XAMPP / WAMP / MAMP / LAMP / Laragon).
5. **Diseño responsive con clases de Bootstrap**:
   - Pantallas pequeñas (<768px): **1 card por fila** (`col-12 col-sm-12`)
   - Pantallas medianas (≥768px): **2 cards por fila** (`col-md-6`)
   - Pantallas grandes (≥992px): **3 cards por fila** (`col-lg-4`) → distribución 3 + 2

## Cómo se ven las tarjetas

**Escritorio (≥992px):**
```
┌─────────┐ ┌─────────┐ ┌─────────┐
│  Card 1 │ │  Card 2 │ │  Card 3 │   ← Primera fila (3)
└─────────┘ └─────────┘ └─────────┘

       ┌─────────┐ ┌─────────┐
       │  Card 4 │ │  Card 5 │       ← Segunda fila (2)
       └─────────┘ └─────────┘
```

**Tablet (≥768px):**
```
┌─────────┐ ┌─────────┐
│  Card 1 │ │  Card 2 │
└─────────┘ └─────────┘
┌─────────┐ ┌─────────┐
│  Card 3 │ │  Card 4 │
└─────────┘ └─────────┘
     ┌─────────┐
     │  Card 5 │
     └─────────┘
```

**Móvil (<768px):**
```
┌─────────┐
│  Card 1 │
└─────────┘
┌─────────┐
│  Card 2 │
└─────────┘
┌─────────┐
│  Card 3 │
└─────────┘
   ...
```

## Instalación y ejecución

1. Copia la carpeta **`ChuckJokesVue`** dentro del directorio público del servidor:

   | Entorno   | Carpeta destino |
   | --------- | --------------- |
   | XAMPP     | `/Applications/XAMPP/xamppfiles/htdocs/` (Mac) o `xampp/htdocs/` |
   | WAMP      | `wamp/www/`     |
   | MAMP      | `/Applications/MAMP/htdocs/` |
   | LAMP      | `/var/www/html/` |
   | Laragon   | `laragon/www/`  |

2. Inicia los servicios de **Apache** desde el panel de control de tu entorno.

3. Abre el navegador en:

   ```
   http://localhost/ChuckJokesVue/
   ```

4. (Opcional) Verifica el endpoint del API directamente:

   ```
   http://localhost/ChuckJokesVue/api/jokes.php
   ```

## Subir el proyecto a GitHub

```bash
cd ChuckJokesVue
git init
git add .
git commit -m "ChuckJokesVue con componente <chuck-card> y Bootstrap"
git branch -M main
git remote add origin https://github.com/<tu-usuario>/ChuckJokesVue.git
git push -u origin main
```
